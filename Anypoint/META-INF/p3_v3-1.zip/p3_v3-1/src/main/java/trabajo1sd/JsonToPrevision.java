package trabajo1sd;

import org.json.*;
import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;

public class JsonToPrevision implements Callable{
@Override
    public Object onCall(MuleEventContext eventContext) throws Exception {

		JSONObject inJson = (JSONObject) eventContext.getMessage().getPayload();
		
		Prevision prevision = new Prevision(inJson);
		
		eventContext.getMessage().setPayload(prevision);
        return eventContext.getMessage().getPayload();
    }
}