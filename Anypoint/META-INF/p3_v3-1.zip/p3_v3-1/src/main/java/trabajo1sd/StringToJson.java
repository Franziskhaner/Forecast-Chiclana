package trabajo1sd;


import org.json.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;

public class StringToJson implements Callable{
@Override
    public Object onCall(MuleEventContext eventContext) throws Exception {
		Document doc = Jsoup.parse(eventContext.getMessage().getPayloadAsString());
		Element div = doc.getElementById("div_wgfcst1");
		String data = div.html();
		int inicio = data.indexOf("wg_fcst_tab_data_1 = ") + 21;
		int fin = data.indexOf(";");
		data = data.substring(inicio, fin);
		//System.out.println(data);
		JSONObject rawJson = new JSONObject(data);
		
		JSONObject finalJson = new JSONObject();
		finalJson.put("waveSize", rawJson.getJSONObject("fcst").getJSONObject("3").get("HTSGW"));
		finalJson.put("waveDir", rawJson.getJSONObject("fcst").getJSONObject("3").get("DIRPW"));
		finalJson.put("wavePeriod", rawJson.getJSONObject("fcst").getJSONObject("3").get("PERPW"));
		finalJson.put("windSpeed", rawJson.getJSONObject("fcst").getJSONObject("3").get("WINDSPD"));
		finalJson.put("windDir", rawJson.getJSONObject("fcst").getJSONObject("3").get("WINDDIR"));
		finalJson.put("spotName", rawJson.get("spot"));
		finalJson.put("dayArray", rawJson.getJSONObject("fcst").getJSONObject("3").get("hr_d"));
		finalJson.put("hourArray", rawJson.getJSONObject("fcst").getJSONObject("3").get("hr_h"));
		finalJson.put("temp", rawJson.getJSONObject("fcst").getJSONObject("3").get("TMP"));
		finalJson.put("rain", rawJson.getJSONObject("fcst").getJSONObject("3").get("APCP"));
		finalJson.put("lowCloud", rawJson.getJSONObject("fcst").getJSONObject("3").get("LCDC"));
		finalJson.put("midCloud", rawJson.getJSONObject("fcst").getJSONObject("3").get("MCDC"));
		finalJson.put("highCloud", rawJson.getJSONObject("fcst").getJSONObject("3").get("HCDC"));

		eventContext.getMessage().setPayload(finalJson);
        return eventContext.getMessage().getPayload();
    }
}