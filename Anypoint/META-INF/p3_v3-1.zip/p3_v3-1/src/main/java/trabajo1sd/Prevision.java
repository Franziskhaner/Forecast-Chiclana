package trabajo1sd;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.json.*;

public class Prevision {
	
	private String _spotName;
	private double _waveSize;
	private double _waveDir;
	private double _wavePeriod;
	private double _windSpeed;
	private int _windDir;
	private int _temp;
	private int _hour;
	private int _day;
	
	public Prevision(JSONObject inJson){
				
		_spotName = inJson.getString("spotName");
		JSONArray aWaveSize = (JSONArray) inJson.get("waveSize");
		JSONArray awaveDir = (JSONArray) inJson.get("waveDir");
		JSONArray aWavePeriod = (JSONArray) inJson.get("wavePeriod");
		JSONArray aWindSpeed = (JSONArray) inJson.get("windSpeed");
		JSONArray aWindDir = (JSONArray) inJson.get("windDir");
		JSONArray aTemp = (JSONArray) inJson.get("temp");
		JSONArray aHour = (JSONArray) inJson.get("hourArray");
		JSONArray aDay = (JSONArray) inJson.get("dayArray");
		
		
		//HORA DEL SISTEMA CON FORMATO
		DateFormat hourFormat = new SimpleDateFormat("HH");
		int systemHour = Integer.parseInt(hourFormat.format(new Date()));
		
		for(int i = 0; i < aWaveSize.length(); i++)
			if(systemHour >= aHour.getInt(i) && systemHour < aHour.getInt(i+1))
			{
				_waveSize = aWaveSize.getDouble(i+1);
				_waveDir = awaveDir.getDouble(i+1);
				_wavePeriod = aWavePeriod.getDouble(i+1);
				_windSpeed = aWindSpeed.getDouble(i+1) * 1.852;	//Pasamos la velocidad del viento de nudos a Km/h
				_windDir = aWindDir.getInt(i+1);
				_temp = aTemp.getInt(i+1);
				_hour = aHour.getInt(i+1);
				_day = aDay.getInt(i+1);
				break;
			}	
	}	
	
	@Override
	public String toString()
	{
		String ret;
		
		ret = _spotName + "\n";
		ret += "Día: " + _day + "   ";
		ret += "Hora: " + _hour + "\n";
		ret += "Ola: " + _waveSize + "m   ";
		ret += "Dir. ola: " + _waveDir + "º   ";
		ret += "Periodo: " + _wavePeriod + "s\n";
		ret += "Viento: " + String.format("%.2f", _windSpeed) + "Km/h   ";
		ret += "Dir. viento: " + _windDir + "º\n";
		ret += "Temp: " + _temp + "º\n";

		return ret;
	}
}